# Overview
Megaman X Vile survivor for Risk Of Rain 2, time to show that i can hunt some maverick monsters better than X!
This mod contais some SFX for shots and voice for some skills!

# Instructions for install:
place the dll in your plugins folder or extract to a folder inside plugins.


# Screenshots
![](https://i.imgur.com/U3deejK.png)
![](https://i.imgur.com/geuxrOl.png)
![](https://i.imgur.com/E4OS5hR.png)
![](https://i.imgur.com/q4egApU.png)
![](https://i.imgur.com/hnDgSRN.png)


# Changelog
V 3.0.0 Update to work with the update and add 2 new skills and some audios
V 2.0.0 Update to work with the update
V 1.0.0 Posted

# Special Thanks
- The RoR2 Modding Community
- My Friends
- My Family
- eXcella who made the MKII skin and the idle animation!! (I will miss the MKII skin T^T)

# Donations
-Please, remember this mod is FREE and aways will be, i made this hoping that you would enjoy and have fun !
-If you want to support me this is the link
https://www.paypal.com/donate?hosted_button_id=JU57WD5QVUC2Y

#CHECK OUT MY OTHER MODS !
-Zero from Megaman X
https://thunderstore.io/package/BLKNeko/MegamanXZeroMod/
-X from Megaman X
https://thunderstore.io/package/BLKNeko/MegamanXMod/

#CREDITS
VILE MODEL ORIGINAL CREDITS!!!
https://drive.google.com/drive/folders/1yU_VyM82efz_ehx6J-IAgAUDmSqDdUJg
